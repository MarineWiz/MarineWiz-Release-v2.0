using System;
using System.Windows;
using System.Runtime.InteropServices;

namespace RemoteTest
{
    public partial class App : Application
    {
    }
}