﻿///////////////////////////////////////////////////////////////////////////////////////
/// Generated Class File by MarineWiz SDK, DO NOT Modify or Remove this comments //////
/// Component: AngularGaugeChart
///////////////////////////////////////////////////////////////////////////////////////
using System.Windows.Threading;
using System;
using MarineWiz.Components;

namespace RemoteTest
{
    public class AngularGaugeChart0_MainWindow_ViewModel : BaseViewModel
    {
        private Double _Value;
        public Double Value
        {
            get
            {
                return _Value;
            }

            set
            {
                _Value = value;
                OnPropertyChanged();
            }
        }

        public AngularGaugeChart0_MainWindow_ViewModel()
        {
        }
    }
}