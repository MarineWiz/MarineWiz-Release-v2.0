using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MarineWiz.Components;
using RemoteSensingConnect;
using RemoteSensingConnect.Model;

namespace RemoteTest
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
#region AngularGaugeChart0 Binding Auto-generation by MarineWiz.
            AngularGaugeChart0.DataContext = new AngularGaugeChart0_MainWindow_ViewModel();
            AngularGaugeChart0.SetBinding(AngularGaugeChart.ValueProperty, new Binding("Value"));
            #endregion


            /*
            Gateway.SensorHandler += (AngularGaugeChart0.DataContext as AngularGaugeChart0_MainWindow_ViewModel).ReceiveData;
            Gateway.Start();
            */



        }
    }
}